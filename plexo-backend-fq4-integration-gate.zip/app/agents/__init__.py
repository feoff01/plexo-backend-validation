"""Orquestração dos agentes: roteador, guardrails, turno (o único lugar que costura banco + LLM + tools)."""
