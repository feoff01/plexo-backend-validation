"""Repositórios finos: SQL explícito, parâmetros nomeados, zero regra de negócio (a regra é do banco)."""
