"""Tools do Educador — família `educacao` (glossário, simulador de juros compostos, exemplo didático).

Toda leitura de conteúdo passa por `content.v_education_approved` (migration 30): o que não foi
aprovado E publicado por compliance não existe para estas tools. Nenhuma premissa numérica no código
(policies EDUCACAO_PARAMS / EDUCACAO_EXEMPLOS). Nenhuma tool opina sobre ativo ou produto.
"""
