from app.config.settings import Settings, get_settings  # noqa: F401
