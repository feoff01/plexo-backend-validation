"""Camada de LLM: interface neutra de provedor, adaptadores, registro de chamadas (llm.model_calls),
orçamento por turno (LLM_BUDGETS) e prompts versionados (llm.prompt_versions)."""
