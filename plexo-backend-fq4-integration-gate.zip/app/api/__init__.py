"""API HTTP do Copiloto — FastAPI + SSE. Identidade v1 por headers (stub de dev, até o auth)."""
